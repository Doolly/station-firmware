#ifndef _ROS_james_msgs_MotorControl_h
#define _ROS_james_msgs_MotorControl_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace james_msgs
{

  class MotorControl : public ros::Msg
  {
    public:
      typedef uint8_t _motor_type;
      _motor_type motor;
      typedef int8_t _direction_type;
      _direction_type direction;
      typedef uint8_t _pwm_type;
      _pwm_type pwm;
      enum { LINEAR_ACTUATOR =  0 };
      enum { CONVEYOR =  1 };
      enum { FORWORD =  1 };
      enum { STOP =  0 };
      enum { REVERSE =  -1 };

    MotorControl():
      motor(0),
      direction(0),
      pwm(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->motor >> (8 * 0)) & 0xFF;
      offset += sizeof(this->motor);
      union {
        int8_t real;
        uint8_t base;
      } u_direction;
      u_direction.real = this->direction;
      *(outbuffer + offset + 0) = (u_direction.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->direction);
      *(outbuffer + offset + 0) = (this->pwm >> (8 * 0)) & 0xFF;
      offset += sizeof(this->pwm);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->motor =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->motor);
      union {
        int8_t real;
        uint8_t base;
      } u_direction;
      u_direction.base = 0;
      u_direction.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->direction = u_direction.real;
      offset += sizeof(this->direction);
      this->pwm =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->pwm);
     return offset;
    }

    const char * getType(){ return "james_msgs/MotorControl"; };
    const char * getMD5(){ return "75a2f766d97aa9c9e789c0ce40fbc026"; };

  };

}
#endif
