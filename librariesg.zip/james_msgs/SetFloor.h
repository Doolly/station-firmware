#ifndef _ROS_SERVICE_SetFloor_h
#define _ROS_SERVICE_SetFloor_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace james_msgs
{

static const char SETFLOOR[] = "james_msgs/SetFloor";

  class SetFloorRequest : public ros::Msg
  {
    public:
      typedef int8_t _floor_type;
      _floor_type floor;

    SetFloorRequest():
      floor(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int8_t real;
        uint8_t base;
      } u_floor;
      u_floor.real = this->floor;
      *(outbuffer + offset + 0) = (u_floor.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->floor);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int8_t real;
        uint8_t base;
      } u_floor;
      u_floor.base = 0;
      u_floor.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->floor = u_floor.real;
      offset += sizeof(this->floor);
     return offset;
    }

    const char * getType(){ return SETFLOOR; };
    const char * getMD5(){ return "918486b8bf6f0e6689e45f56558d7c7b"; };

  };

  class SetFloorResponse : public ros::Msg
  {
    public:

    SetFloorResponse()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
     return offset;
    }

    const char * getType(){ return SETFLOOR; };
    const char * getMD5(){ return "d41d8cd98f00b204e9800998ecf8427e"; };

  };

  class SetFloor {
    public:
    typedef SetFloorRequest Request;
    typedef SetFloorResponse Response;
  };

}
#endif
